<div class="explore">
    <div class="explore__header">
        <p class="explore__heading">Explore Our Products</p>
    </div>
    <div class="explore__main"><?php echo do_shortcode('[products orderby=”random” limit=8]') ?></div>
</div>