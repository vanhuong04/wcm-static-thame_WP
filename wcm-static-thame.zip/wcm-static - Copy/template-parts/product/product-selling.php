<div class="explore">
    <div class="explore__header">
        <p class="explore__heading">Best Selling</p>
    </div>
    <div class="explore__main"><?php echo do_shortcode('[products obest_selling=”true” limit=4]') ?></div>
</div>